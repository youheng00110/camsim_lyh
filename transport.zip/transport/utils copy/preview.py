import av
import torch
import torchvision
import sys

def _get_preview_view_count_from_batch(batch: dict, default_view_count: int) -> int:
    """
    Read dataset_tag (int tensor) from batch and map to the real camera count:
      0: nuplan -> 8
      1: nuscenes -> 6
      2: waymo -> 5
      3: argoverse -> 7
    Only used for preview display (do NOT change model inputs).
    """
    tag2v = {0: 8, 1: 6, 2: 5, 3: 7}

    t = batch.get("dataset_tag", None)
    if not torch.is_tensor(t) or t.numel() == 0:
        return default_view_count

    tag = int(t.reshape(-1)[0].item())
    return min(default_view_count, int(tag2v.get(tag, default_view_count)))
        ####
        ####增加对输出进行对应数据集的筛选流程，改了两个函数（make_ctsd_preview_tensor）###
        ####
def make_ctsd_preview_tensor(output_images, batch, inference_config):
    batch_size, _, view_count = batch["vae_images"].shape[:3]

    output_images = output_images.cpu().unflatten(0, (batch_size, -1, view_count))
    sequence_length = output_images.shape[1]
    preview_v = _get_preview_view_count_from_batch(batch, view_count)

    collected_images = [batch["vae_images"][:, :sequence_length, :preview_v]]

    if "3dbox_images" in batch:
        collected_images.append(batch["3dbox_images"][:, :sequence_length, :preview_v])

    if "hdmap_images" in batch:
        collected_images.append(batch["hdmap_images"][:, :sequence_length, :preview_v])

    collected_images.append(output_images[:, :, :preview_v])

    stacked_images = torch.stack(collected_images)

    if inference_config.get("force_preview_resize", False):
        preview_images = torch.nn.functional.interpolate(
            stacked_images.flatten(0, 3),
            tuple(inference_config["preview_image_size"][::-1])
        )
        preview_images = preview_images.view(
            *stacked_images.shape[:4], -1, *preview_images.shape[-2:]
        )
    else:
        preview_images = stacked_images

    if sequence_length == 1:
        preview_tensor = preview_images.permute(4, 1, 2, 0, 5, 3, 6) \
            .flatten(-2).flatten(1, 4)
    else:
        preview_tensor = preview_images.permute(2, 4, 1, 0, 5, 3, 6) \
            .flatten(-2).flatten(2, 4)

    return preview_tensor

def make_ctsd_preview_wan(output_images, batch, inference_config):
    batch_size, _, view_count = batch["vae_images"].shape[:3]

    output_images = output_images.cpu()

    if output_images.ndim == 6:
        # new format: [B, T, V, C, H, W]
        if output_images.shape[0] != batch_size:
            raise ValueError(
                f"output_images batch mismatch: got {tuple(output_images.shape)}, "
                f"expected batch_size={batch_size}"
            )
        if output_images.shape[2] != view_count:
            raise ValueError(
                f"output_images view mismatch: got {tuple(output_images.shape)}, "
                f"expected view_count={view_count}"
            )
    elif output_images.ndim == 4:
        # old format: [B*T*V, C, H, W]
        if output_images.shape[0] % (batch_size * view_count) != 0:
            raise ValueError(
                f"cannot unflatten output_images with shape {tuple(output_images.shape)} "
                f"using batch_size={batch_size}, view_count={view_count}"
            )
        output_images = output_images.unflatten(0, (batch_size, -1, view_count))
    else:
        raise ValueError(
            f"unsupported output_images shape: {tuple(output_images.shape)}"
        )

    sequence_length = output_images.shape[1]

    collected_images = [batch["vae_images"][:, :sequence_length]]

    if "3dbox_images" in batch:
        collected_images.append(batch["3dbox_images"][:, :sequence_length])

    if "hdmap_images" in batch:
        collected_images.append(batch["hdmap_images"][:, :sequence_length])

    if "proj_clr" in batch:
        collected_images.append(batch["proj_clr"][:, :sequence_length])

    if "vis_depth" in batch:
        collected_images.append(batch["vis_depth"][:, :sequence_length])

    collected_images.append(output_images)

    stacked_images = torch.stack(collected_images)

    if sequence_length == 1:
        preview_tensor = stacked_images.permute(4, 1, 2, 0, 5, 3, 6).flatten(-2).flatten(1, 4)
    else:
        preview_tensor = stacked_images.permute(2, 4, 1, 0, 5, 3, 6).flatten(-2).flatten(2, 4)

    return preview_tensor

def make_lidar_preview_tensor(
    ground_truth_volumn, generated_volumn, batch, inference_config
):
    collected_images = [
        ground_truth_volumn.amax(-3, keepdim=True).repeat_interleave(3, -3)
        .cpu()
    ]
    if "3dbox_bev_images_denorm" in batch:
        collected_images.append(batch["3dbox_bev_images_denorm"])

    if "hdmap_bev_images_denorm" in batch:
        collected_images.append(batch["hdmap_bev_images_denorm"])

    if isinstance(generated_volumn, list):
        for gv in generated_volumn:
            collected_images.append(
                gv.amax(-3, keepdim=True).repeat_interleave(3, -3).cpu())
    else:
        collected_images.append(
            generated_volumn.amax(-3, keepdim=True).repeat_interleave(3, -3).cpu())

    # assume all BEV images have the same size
    stacked_images = torch.stack(collected_images)
    if ground_truth_volumn.shape[1] == 1:
        # BEV image preview with shape [C, B * T * H, S * W]
        preview_tensor = stacked_images.permute(3, 1, 2, 4, 0, 5).flatten(-2)\
            .flatten(1, 3)
    else:
        # BEV video preview with shape [T, C, B * H, S * W]
        preview_tensor = stacked_images.permute(2, 3, 1, 4, 0, 5).flatten(-2)\
            .flatten(2, 3)

    return preview_tensor


def save_tensor_to_video(
    path: str, video_encoder: str, fps, tensor_list, pix_fmt: str = "yuv420p",
    stream_options: dict = {"crf": "16"}
):
    tensor_shape = tensor_list[0].shape
    with av.open(path, mode="w") as container:
        stream = container.add_stream(video_encoder, int(fps))
        stream.width = tensor_shape[-1]
        stream.height = tensor_shape[-2]
        stream.pix_fmt = pix_fmt
        stream.options = stream_options
        for i in tensor_list:
            frame = av.VideoFrame.from_image(
                torchvision.transforms.functional.to_pil_image(i))
            for p in stream.encode(frame):
                container.mux(p)

        for p in stream.encode():
            container.mux(p)


def gray_to_colormap(img, cmap='rainbow', max_val=None):
    """
    Transfer gray map to matplotlib colormap
    """
    assert img.ndim == 2
    import matplotlib
    import matplotlib.cm

    img[img<0] = 0
    mask_invalid = img < 1e-10
    if max_val is None:
        img = img / (img.max() + 1e-8)
    else:
        img = img / (max_val + 1e-8)
    norm = matplotlib.colors.Normalize(vmin=0, vmax=1.1)
    cmap_m = matplotlib.cm.get_cmap(cmap)
    map = matplotlib.cm.ScalarMappable(norm=norm, cmap=cmap_m)
    colormap = map.to_rgba(img)[:, :, :3]
    colormap[mask_invalid] = 0
    return colormap

def depths_to_colors(depths, concat="width", colormap="rainbow", max_val=None):
    colors = []
    if isinstance(depths, list) or len(depths.shape) == 4:
        for depth in depths:
            color = gray_to_colormap(depth.detach().cpu().numpy(), cmap=colormap, max_val=max_val)
            colors.append(color.permute(2, 0, 1))
        if concat == "width":
            colors = torch.cat(colors, dim=2)
        else:
            colors = torch.stack(colors)
    else:
        colors = gray_to_colormap(depths.detach().cpu().numpy(), cmap=colormap, max_val=max_val)
        colors = torch.from_numpy(colors).permute(2, 0, 1)
    return colors
