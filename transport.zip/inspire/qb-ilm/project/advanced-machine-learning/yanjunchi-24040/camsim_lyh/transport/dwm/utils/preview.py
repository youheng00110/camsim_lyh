import av
import torch
import torchvision
import sys
import os

def _get_preview_view_count_from_batch(batch: dict, default_view_count: int) -> int:
    """
    Read dataset_tag (int tensor) from batch and map to the real camera count:
      0: nuplan -> 8
      1: nuscenes -> 6
      2: waymo -> 5
      3: argoverse -> 7
    Only used for preview display (do NOT change model inputs).
    """
    tag2v = {0: 8, 1: 6, 2: 5, 3: 7}

    t = batch.get("dataset_tag", None)
    if not torch.is_tensor(t) or t.numel() == 0:
        return default_view_count

    tag = int(t.reshape(-1)[0].item())
    return min(default_view_count, int(tag2v.get(tag, default_view_count)))
        ####
        ####增加对输出进行对应数据集的筛选流程，改了两个函数（make_ctsd_preview_tensor）###
        ####
def make_ctsd_preview_tensor(output_images, batch, inference_config):
    batch_size, _, view_count = batch["vae_images"].shape[:3]

    output_images = output_images.cpu().unflatten(0, (batch_size, -1, view_count))
    sequence_length = output_images.shape[1]
    preview_v = _get_preview_view_count_from_batch(batch, view_count)

    collected_images = [batch["vae_images"][:, :sequence_length, :preview_v]]

    if "3dbox_images" in batch:
        collected_images.append(batch["3dbox_images"][:, :sequence_length, :preview_v])

    if "hdmap_images" in batch:
        collected_images.append(batch["hdmap_images"][:, :sequence_length, :preview_v])

    collected_images.append(output_images[:, :, :preview_v])

    stacked_images = torch.stack(collected_images)

    if inference_config.get("force_preview_resize", False):
        preview_images = torch.nn.functional.interpolate(
            stacked_images.flatten(0, 3),
            tuple(inference_config["preview_image_size"][::-1])
        )
        preview_images = preview_images.view(
            *stacked_images.shape[:4], -1, *preview_images.shape[-2:]
        )
    else:
        preview_images = stacked_images

    if sequence_length == 1:
        preview_tensor = preview_images.permute(4, 1, 2, 0, 5, 3, 6) \
            .flatten(-2).flatten(1, 4)
    else:
        preview_tensor = preview_images.permute(2, 4, 1, 0, 5, 3, 6) \
            .flatten(-2).flatten(2, 4)

    return preview_tensor

def make_ctsd_preview_wan(output_images, batch, inference_config):
    batch_size, _, view_count = batch["vae_images"].shape[:3]

    output_images = output_images.cpu()

    if output_images.ndim == 6:
        # new format: [B, T, V, C, H, W]
        if output_images.shape[0] != batch_size:
            raise ValueError(
                f"output_images batch mismatch: got {tuple(output_images.shape)}, "
                f"expected batch_size={batch_size}"
            )
        if output_images.shape[2] != view_count:
            raise ValueError(
                f"output_images view mismatch: got {tuple(output_images.shape)}, "
                f"expected view_count={view_count}"
            )
    elif output_images.ndim == 4:
        # old format: [B*T*V, C, H, W]
        if output_images.shape[0] % (batch_size * view_count) != 0:
            raise ValueError(
                f"cannot unflatten output_images with shape {tuple(output_images.shape)} "
                f"using batch_size={batch_size}, view_count={view_count}"
            )
        output_images = output_images.unflatten(0, (batch_size, -1, view_count))
    else:
        raise ValueError(
            f"unsupported output_images shape: {tuple(output_images.shape)}"
        )

    sequence_length = output_images.shape[1]

    collected_images = [batch["vae_images"][:, :sequence_length]]

    if "3dbox_images" in batch:
        collected_images.append(batch["3dbox_images"][:, :sequence_length])

    if "hdmap_images" in batch:
        collected_images.append(batch["hdmap_images"][:, :sequence_length])

    if "proj_clr" in batch:
        collected_images.append(batch["proj_clr"][:, :sequence_length])

    if "vis_depth" in batch:
        collected_images.append(batch["vis_depth"][:, :sequence_length])

    collected_images.append(output_images)

    stacked_images = torch.stack(collected_images)

    if sequence_length == 1:
        preview_tensor = stacked_images.permute(4, 1, 2, 0, 5, 3, 6).flatten(-2).flatten(1, 4)
    else:
        preview_tensor = stacked_images.permute(2, 4, 1, 0, 5, 3, 6).flatten(-2).flatten(2, 4)

    return preview_tensor

def make_lidar_preview_tensor(
    ground_truth_volumn, generated_volumn, batch, inference_config
):
    collected_images = [
        ground_truth_volumn.amax(-3, keepdim=True).repeat_interleave(3, -3)
        .cpu()
    ]
    if "3dbox_bev_images_denorm" in batch:
        collected_images.append(batch["3dbox_bev_images_denorm"])

    if "hdmap_bev_images_denorm" in batch:
        collected_images.append(batch["hdmap_bev_images_denorm"])

    if isinstance(generated_volumn, list):
        for gv in generated_volumn:
            collected_images.append(
                gv.amax(-3, keepdim=True).repeat_interleave(3, -3).cpu())
    else:
        collected_images.append(
            generated_volumn.amax(-3, keepdim=True).repeat_interleave(3, -3).cpu())

    # assume all BEV images have the same size
    stacked_images = torch.stack(collected_images)
    if ground_truth_volumn.shape[1] == 1:
        # BEV image preview with shape [C, B * T * H, S * W]
        preview_tensor = stacked_images.permute(3, 1, 2, 4, 0, 5).flatten(-2)\
            .flatten(1, 3)
    else:
        # BEV video preview with shape [T, C, B * H, S * W]
        preview_tensor = stacked_images.permute(2, 3, 1, 4, 0, 5).flatten(-2)\
            .flatten(2, 3)

    return preview_tensor


def save_tensor_to_video(
    path: str, video_encoder: str, fps, tensor_list, pix_fmt: str = "yuv420p",
    stream_options: dict = {"crf": "16"}
):
    tensor_shape = tensor_list[0].shape
    with av.open(path, mode="w") as container:
        stream = container.add_stream(video_encoder, int(fps))
        stream.width = tensor_shape[-1]
        stream.height = tensor_shape[-2]
        stream.pix_fmt = pix_fmt
        stream.options = stream_options
        for i in tensor_list:
            frame = av.VideoFrame.from_image(
                torchvision.transforms.functional.to_pil_image(i))
            for p in stream.encode(frame):
                container.mux(p)

        for p in stream.encode():
            container.mux(p)


def gray_to_colormap(img, cmap='rainbow', max_val=None):
    """
    Transfer gray map to matplotlib colormap
    """
    assert img.ndim == 2
    import matplotlib
    import matplotlib.cm

    img[img<0] = 0
    mask_invalid = img < 1e-10
    if max_val is None:
        img = img / (img.max() + 1e-8)
    else:
        img = img / (max_val + 1e-8)
    norm = matplotlib.colors.Normalize(vmin=0, vmax=1.1)
    cmap_m = matplotlib.cm.get_cmap(cmap)
    map = matplotlib.cm.ScalarMappable(norm=norm, cmap=cmap_m)
    colormap = map.to_rgba(img)[:, :, :3]
    colormap[mask_invalid] = 0
    return colormap

def depths_to_colors(depths, concat="width", colormap="rainbow", max_val=None):
    colors = []
    if isinstance(depths, list) or len(depths.shape) == 4:
        for depth in depths:
            color = gray_to_colormap(depth.detach().cpu().numpy(), cmap=colormap, max_val=max_val)
            colors.append(color.permute(2, 0, 1))
        if concat == "width":
            colors = torch.cat(colors, dim=2)
        else:
            colors = torch.stack(colors)
    else:
        colors = gray_to_colormap(depths.detach().cpu().numpy(), cmap=colormap, max_val=max_val)
        colors = torch.from_numpy(colors).permute(2, 0, 1)
    return colors


def _preview_eval_rank0():
    if not torch.distributed.is_available():
        return True
    if not torch.distributed.is_initialized():
        return True
    return torch.distributed.get_rank() == 0


def _preview_tensor_to_pil(image_tensor, size_tuple=None):
    image_tensor = image_tensor.detach().cpu().float().clamp(0, 1)
    image = torchvision.transforms.functional.to_pil_image(image_tensor)
    if size_tuple is not None and image.size != size_tuple:
        image = image.resize(size_tuple)
    return image


def _preview_json_tensor(value):
    if torch.is_tensor(value):
        return value.detach().cpu().tolist()
    return value


def _preview_image_size_tuple(image_size_tensor):
    image_size = image_size_tensor.detach().cpu().tolist()
    width = int(round(float(image_size[0])))
    height = int(round(float(image_size[1])))
    return width, height


def _preview_get_camera_names(batch, view_count):
    for key in ["camera_names", "sensor_channels", "view_names", "camera_channels"]:
        value = batch.get(key, None)
        if isinstance(value, list) and len(value) == view_count:
            if all(isinstance(x, str) for x in value):
                return [str(x) for x in value]
        if isinstance(value, list) and len(value) > 0:
            first = value[0]
            if isinstance(first, list) and len(first) == view_count:
                if all(isinstance(x, str) for x in first):
                    return [str(x) for x in first]

    return [f"CAM_{i:02d}" for i in range(view_count)]


def _preview_count_manifest_lines(path):
    if not os.path.exists(path):
        return 0

    count = 0
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                count += 1
    return count


def _preview_output_to_b_t_v(output_images, batch, inference_config):
    batch_size, sequence_length, view_count = batch["vae_images"].shape[:3]
    reference_frame_count = int(inference_config.get("reference_frame_count", 0))
    reference_frame_count = min(reference_frame_count, sequence_length)
    generate_frames_for_reference = bool(
        inference_config.get("generate_frames_for_reference", True)
    )

    output_images = output_images.detach().cpu()

    if output_images.ndim == 6:
        generated = output_images
    elif output_images.ndim == 4:
        if output_images.shape[0] % (batch_size * view_count) != 0:
            raise ValueError(
                f"Cannot unflatten output_images shape={tuple(output_images.shape)} "
                f"with B={batch_size}, V={view_count}."
            )
        generated = output_images.unflatten(0, (batch_size, -1, view_count))
    else:
        raise ValueError(f"Unsupported output_images shape: {tuple(output_images.shape)}")

    if generated.shape[0] != batch_size:
        raise ValueError(
            f"Generated batch mismatch: got {generated.shape[0]}, expected {batch_size}."
        )
    if generated.shape[2] != view_count:
        raise ValueError(
            f"Generated view mismatch: got {generated.shape[2]}, expected {view_count}."
        )

    generated_length = generated.shape[1]

    # Case 1: output already contains all preview frames.
    if generated_length == sequence_length:
        reference_flags = torch.zeros((sequence_length,), dtype=torch.bool)
        return generated, reference_flags

    # Case 2: CTSD / autoregressive preview.
    # This mirrors camsim.py exactly:
    # if generate_frames_for_reference=False, preview video is
    # [GT reference frames] + [pipeline_output images].
    if not generate_frames_for_reference and reference_frame_count > 0:
        prefix_images = batch["vae_images"][:, :reference_frame_count].detach().cpu()
        full = torch.cat([prefix_images, generated], dim=1)

        reference_flags = torch.zeros((full.shape[1],), dtype=torch.bool)
        reference_flags[:reference_frame_count] = True
        return full, reference_flags

    # Case 3: no reference frames should be inserted.
    reference_flags = torch.zeros((generated_length,), dtype=torch.bool)
    return generated, reference_flags


def save_ctsd_eval_frames_for_preview(
    output_images,
    batch,
    inference_config,
    output_dir,
    dataset_name="unknown",
    manifest_name="stflow_manifest.jsonl",
    image_quality=95,
    export_paired_real=True,
):
    """Save per-view fake/real frames from the exact preview output.

    fake:
        output_dir/images/{video_id}/tXXX/{camera}.jpg
    real:
        output_dir/paired_real/{video_id}/tXXX/{camera}.jpg
    manifest:
        output_dir/stflow_manifest.jsonl

    This function preserves reference-frame behavior:
    if generate_frames_for_reference=False and output_images does not contain
    reference frames, the first reference_frame_count fake frames are copied
    from batch["vae_images"].
    """
    if not _preview_eval_rank0():
        return

    os.makedirs(output_dir, exist_ok=True)
    manifest_path = os.path.join(output_dir, manifest_name)

    fake_images, reference_flags = _preview_output_to_b_t_v(
        output_images, batch, inference_config
    )

    real_images = batch["vae_images"].detach().cpu()
    batch_size, sequence_length, view_count = real_images.shape[:3]
    camera_names = _preview_get_camera_names(batch, view_count)
    video_offset = _preview_count_manifest_lines(manifest_path)

    with open(manifest_path, "a", encoding="utf-8") as manifest_file:
        for b in range(batch_size):
            video_id = f"{dataset_name}_video_{video_offset + b:06d}"
            frames = []

            for t in range(sequence_length):
                frame_record = {
                    "frame_index": t,
                    "views": [],
                }

                if "ego_transforms" in batch:
                    ego_transform = batch["ego_transforms"][b, t]
                    if ego_transform.ndim == 3:
                        ego_transform = ego_transform[0]
                    frame_record["T_ego_to_world"] = _preview_json_tensor(ego_transform)

                for v in range(view_count):
                    camera_name = camera_names[v]
                    size_tuple = None
                    if "image_size" in batch:
                        size_tuple = _preview_image_size_tuple(batch["image_size"][b, t, v])

                    fake_rel = os.path.join(
                        "images",
                        video_id,
                        f"t{t:03d}",
                        f"{camera_name}.jpg",
                    )
                    fake_abs = os.path.join(output_dir, fake_rel)
                    os.makedirs(os.path.dirname(fake_abs), exist_ok=True)
                    _preview_tensor_to_pil(fake_images[b, t, v], size_tuple).save(
                        fake_abs,
                        quality=image_quality,
                    )

                    real_rel = None
                    if export_paired_real:
                        real_rel = os.path.join(
                            "paired_real",
                            video_id,
                            f"t{t:03d}",
                            f"{camera_name}.jpg",
                        )
                        real_abs = os.path.join(output_dir, real_rel)
                        os.makedirs(os.path.dirname(real_abs), exist_ok=True)
                        _preview_tensor_to_pil(real_images[b, t, v], size_tuple).save(
                            real_abs,
                            quality=image_quality,
                        )

                    view_record = {
                        "camera": camera_name,
                        "image_path": fake_rel,
                        "real_image_path": real_rel,
                        "valid_mask_path": None,
                    }

                    if "camera_intrinsics" in batch:
                        view_record["K"] = _preview_json_tensor(
                            batch["camera_intrinsics"][b, t, v]
                        )
                    if "camera_transforms" in batch:
                        view_record["T_cam_to_ego"] = _preview_json_tensor(
                            batch["camera_transforms"][b, t, v]
                        )
                    if "image_size" in batch:
                        view_record["image_size"] = _preview_json_tensor(
                            batch["image_size"][b, t, v]
                        )
                    if bool(reference_flags[t].item()):
                        view_record["is_reference_frame"] = True

                    frame_record["views"].append(view_record)

                frames.append(frame_record)

            manifest_item = {
                "video_id": video_id,
                "dataset_name": dataset_name,
                "reference_frame_count": int(
                    inference_config.get("reference_frame_count", 0)
                ),
                "generate_frames_for_reference": bool(
                    inference_config.get("generate_frames_for_reference", True)
                ),
                "frames": frames,
            }
            import json
            manifest_file.write(json.dumps(manifest_item, ensure_ascii=False) + "\n")
            manifest_file.flush()

            print(
                f"[PREVIEW_EVAL_EXPORT] saved {video_id} to {output_dir}",
                flush=True,
            )
